package ouka;

import java.util.Calendar;
import javax.swing.*;

public class data {
    public data() {}

    public String dia_da_semana(String cronometro){

int crono = cronometro.indexOf("/");
int dia = Integer.parseInt(cronometro.substring(0, crono));
int mes = Integer.parseInt(cronometro.substring(crono+1, crono+3));
int ano = Integer.parseInt(cronometro.substring(crono+4, crono+8));

        Calendar DataToda = Calendar.getInstance();
        DataToda.set(java.util.Calendar.YEAR, ano);
        DataToda.set(java.util.Calendar.MONTH, mes - 1);
        DataToda.set(java.util.Calendar.DATE, dia);
int Dia_da_semana= DataToda.get(Calendar.DAY_OF_WEEK);

String semana[];
        semana = new String[8];
semana[0]="";
semana[1]="Domingo";
semana[2]="Segunda";
semana[3]="Terça";
semana[4]="Quarta";
semana[5]="Quinta";
semana[6]="Sexta";
semana[7]="Sabado";
String Semana_atual = semana[Dia_da_semana];

return Semana_atual;
}

public  String data_atual(){

        Calendar DataToda = Calendar.getInstance();

            int Dia_do_mes = DataToda.get(Calendar.DATE);
        int Mes = DataToda.get(Calendar.MONTH)+1;
        int Ano = DataToda.get(Calendar.YEAR);


String _Dia_do_mes = (Dia_do_mes < 10) ? "0"+Dia_do_mes : ""+Dia_do_mes;
String _Mes = (Mes < 10) ? "0"+Mes : ""+Mes;

return _Dia_do_mes+"/"+_Mes+"/"+Ano;
}

public String hora_atual(){
      Calendar DataToda = Calendar.getInstance();

        int Horas = DataToda.get(Calendar.HOUR_OF_DAY);
        int Minutos = DataToda.get(Calendar.MINUTE);
        int Segundos = DataToda.get(Calendar.SECOND);

String _Horas = (Horas < 10 ) ? "0"+Horas : ""+Horas;
String _Minutos = (Minutos < 10 ) ? "0"+Minutos : ""+Minutos;
String _Segundos = (Segundos < 10) ? "0"+Segundos : ""+Segundos;

return _Horas+":"+_Minutos+":"+_Segundos;
}

public boolean hora_erro(String cronometro){

int crono = cronometro.indexOf(":");
int horas = Integer.parseInt(cronometro.substring(0, crono));
int minutos = Integer.parseInt(cronometro.substring(crono+1, crono+3));
int segundos = Integer.parseInt(cronometro.substring(crono+4, crono+6));

if(cronometro.length() != 8) {
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
if(cronometro.indexOf(":") != 2){
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
if(cronometro.indexOf(":", 3) != 5){
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
if(horas < 0 || horas > 24) {
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
if(minutos < 0 || minutos > 60) {
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
if(segundos < 0 || segundos > 60) {
JOptionPane.showMessageDialog(null, "Erro: hora inválida!");
return false; 
}
return true;
}

public boolean data_erro(String cronometro){

int crono = cronometro.indexOf("/");
int dia = Integer.parseInt(cronometro.substring(0, crono));
int mes = Integer.parseInt(cronometro.substring(crono+1, crono+3));
int ano = Integer.parseInt(cronometro.substring(crono+4, crono+8));
int _cronometro = cronometro.length();
if(_cronometro != 10) {
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}
if(cronometro.indexOf("/") != 2){
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}
if(cronometro.indexOf("/", 3) != 5){
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}

if(dia <= 0 || dia > 31) {
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}
if(mes <= 0 || mes > 12) {
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}
if(ano <= 1700 || ano >= 2900){
JOptionPane.showMessageDialog(null, "Erro: data inválida!");
return false; 
}
return true;
}

public int hora_p_seg(String cronometro) {

// exemplo: hora_p_seg("2:20:25");
// resultado 
cronometro = cronometro.toString();
int crono = cronometro.indexOf(":");
int horas = Integer.parseInt(cronometro.substring(0, crono));
int minutos = Integer.parseInt(cronometro.substring(crono+1, crono+3));
int segundos = Integer.parseInt(cronometro.substring(crono+4, crono+6));

return (horas * 60 * 60) + ( minutos * 60) + segundos;
}

public String[] seg_p_hora(int cronometro) {

// exemplo: seg_p_hora(13479);
// resultado: Array(0, "03:44:39");

int horas = ((cronometro / (60 * 60)) % 24);
String _horas = (horas < 10 ) ? "0"+horas : ""+horas;
int minutos = ((cronometro % (60 * 60) )/ 60);
String _minutos = (minutos < 10 ) ? "0"+minutos : ""+minutos;
int segundos = cronometro % 60;
String _segundos = (segundos < 10) ? "0"+segundos : ""+segundos;
int dias = (cronometro / (24 * 60 * 60));
String _dias = ""+dias;
_horas = _horas +":"+_minutos+":"+_segundos;
String ee[];
ee = new String[2];
ee[0] = _dias;
ee[1] = _horas;
return ee;
}

public int data_p_dia(String cronometro) {
// exemplo: data_p_dia("14/11/2006");
// resultado: 318

int crono = cronometro.indexOf("/");
int dia = Integer.parseInt(cronometro.substring(0, crono));
int mes = Integer.parseInt(cronometro.substring(crono+1, crono+3));
int ano = Integer.parseInt(cronometro.substring(crono+4, crono+8));

int dias = 0;

if(mes > 1) {
dias += 31;
}
if(mes > 2) {
	if(ano % 4 != 0) {
		dias += 28;
	} else {
		dias += 29;
	}
}
if(mes > 3) {
dias += 31;
}
if(mes > 4) {
dias += 30;
}
if(mes > 5) {
dias += 31;
}
if(mes > 6) {
dias += 30;
}
if(mes > 7) {
dias += 31;
}
if(mes > 8) {
dias += 31;
}
if(mes > 9) {
dias += 30;
}
if(mes > 10) {
dias += 31;
}
if(mes > 11) {
dias += 30;
}
if(mes > 12) {
dias += 31;
}

dias += dia;

return dias;
}

public String dia_p_data(int cronometro, int ano) {
// exemplo: dia_p_data(318, 2009);
// resultado: "14/11/2009"

int dia = 0;
int mes = 0;
boolean canselar = false;
while (cronometro >= 366) {
if(cronometro > 365 && ano % 4 != 0){ 
ano += 1;
cronometro -= 365;
}
if(cronometro > 366 && ano % 4 == 0) {
ano +=1;
cronometro -= 366;
}
if(cronometro == 366 && ano % 4 == 0){
break;
}
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 1;
canselar = true;
} else {
cronometro -= 31;
}

if((cronometro <= 29) && (ano % 4 == 0) && canselar == false) {
	dia = cronometro;
	mes = 2;
	canselar = true;
} else if((cronometro <= 28) && (ano % 4 != 0) && canselar == false){
	dia = cronometro;
	mes = 2;
	canselar = true;
} else if((cronometro > 29) && (ano % 4 == 0)) {
	cronometro -= 29;
} else if((cronometro > 28) && (ano % 4 != 0)) {
	cronometro -= 28;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 3;
canselar = true;
} else {
cronometro -= 31;
}

if(cronometro <= 30 && canselar == false) {
dia = cronometro;
mes = 4;
canselar = true;
} else {
cronometro -= 30;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 5;
canselar = true;
} else {
cronometro -= 31;
}

if(cronometro <= 30 && canselar == false) {
dia = cronometro;
mes = 6;
canselar = true;
} else {
cronometro -= 30;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 7;
canselar = true;
} else {
cronometro -= 31;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 8;
canselar = true;
} else {
cronometro -= 31;
}

if(cronometro <= 30 && canselar == false) {
dia = cronometro;
mes = 9;
canselar = true;
} else {
cronometro -= 30;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 10;
canselar = true;
} else {
cronometro -= 31;
}

if(cronometro <= 30 && canselar == false) {
dia = cronometro;
mes = 11;
canselar = true;
} else {
cronometro -= 30;
}

if(cronometro <= 31 && canselar == false) {
dia = cronometro;
mes = 12;
canselar = true;
} else {
cronometro -= 31;
}

String _dia = (dia < 10) ? "0"+dia : ""+dia;
String _mes = (mes < 10) ? "0"+mes : ""+mes;
return _dia+"/"+_mes+"/"+ano;
}

public int anos_p_dias(int ano1, int ano2_menos_1) {
// exemplo: anos_p_dias(2006, 2009 -> 2009 - 1 = 2008);

int dias = 0;
for (int x = ano1; x < ano2_menos_1; x++) {
	if(x % 4 == 0){
	dias += 366;
	} else {
	dias += 365;
	}
}
return dias;
}

public String soma_data(String cronometro, int dias) {
// exemplo: soma_data("14/11/2009", +10);
// resultado: "24/11/2009"

int crono = cronometro.indexOf("/");
int ano = Integer.parseInt(cronometro.substring(crono+4, crono+8));

int _cronometro = data_p_dia(cronometro);
_cronometro += dias;
return dia_p_data(_cronometro, ano);
}

public String[] soma_hora(int dias, String cronometro, int segundos) {
// exemplo: soma_hora(3, "20:30:25", +30);
// resultado: Array(3, 20:30:55)

dias = dias * (24 * 60 * 60);
int _crono = 0;
_crono += segundos;
_crono += dias;
int _cronometro = hora_p_seg(cronometro);
_cronometro += _crono;
return seg_p_hora(_cronometro);
}

public int data_p_data(String data_menor, String data_maior) {
// exemplo: data_p_data("14/11/2006", "14/10/2009");
// resultado: 1065

int crono = data_menor.indexOf("/");
int ano_menor = Integer.parseInt(data_menor.substring(crono+4, crono+8));

    crono = data_maior.indexOf("/");
int ano_maior = Integer.parseInt(data_maior.substring(crono+4, crono+8));

int dias_ano = anos_p_dias(ano_menor, ano_maior);

int dias_menor = data_p_dia(data_menor);

int dias_maior = data_p_dia(data_maior);

return dias_ano - dias_menor + dias_maior;
}

public int hora_p_hora(int dia_menor, String hora_menor, int dia_maior, String hora_maior) {

dia_menor = dia_menor * (24 * 60 * 60);
int _hora_menor = hora_p_seg(hora_menor);

_hora_menor += dia_menor;

dia_maior = dia_maior * (24 * 60 * 60);
int _hora_maior = hora_p_seg(hora_maior);

_hora_maior += dia_maior;

return _hora_maior - _hora_menor;
}   
}
